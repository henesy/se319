Open .html file for the respective calculators, enter a number, then select an operator, then enter another number, pressing "=" to solve.

Memory functions should operate as expected with a single register storing previous numbers.
