login.[html,js] processes username/password and leads to booksLibrary.[html,js]. Should a malformed URL (used to differentiate between librarian and undergrad views) be received by the library, an alert is issued with a warning and the user is re-directed to the login page. 

code.[html,js] is split into parts 1, 2, and 3 which are the style elements, jquery effects, and  events respectively (5 of each as per the PDF instructions). The first two are primarily actuated through labelled buttons divided by section, while the last section requires more manual interaction (and prompts as such).

booksLibrary.[html,js] hosts the book library as per the instructions and is re-directed to via the login.[html,js] system and should act and store as per the PDF instructions.
