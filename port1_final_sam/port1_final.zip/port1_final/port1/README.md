Portfolio One by Sean Hinchee and Sam Westerlund (Group 20)

Languages:

- Golang (Go) version 1.7.5 linux/amd64
- Golang (Go) version 1.7.5 windows/amd64
- JavaScript
- HTML5

To Build: Simply `make`

To Run: Simply `./port1` or run `port1.exe` on Windows

To Play: Go to `http://localhost:13337` or `http://proj-319-020.cs.iastate.edu/`

Summary: A simple web game powered by Golang which allows two players to enjoy a game of Go together.

Notes: Firefox is the recommended (tested) browser for Go Squared. Browser may need to be full screen for correct placement of pieces.
