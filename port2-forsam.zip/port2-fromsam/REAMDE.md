# Requirements

Node JS: https://nodejs.org/en/

# To Run

From the project's working directory:

`node server.js`

# To Use

http://localhost:8080/
