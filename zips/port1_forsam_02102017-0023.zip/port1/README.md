Portfolio One by Sean Hinchee (Group 20)

Languages:

- Golang (Go) version 1.7.5 linux/amd64
- Golang (Go) version 1.7.5 windows/amd64
- JavaScript
- HTML5

To Build: Simply `make`

To Run: Simply `./port1` or run `port1.exe` on Windows

To Play: Go to `http://localhost:13337`

Summary: A simple web game powered by Golang which allows two players to enjoy a game of Go together.
